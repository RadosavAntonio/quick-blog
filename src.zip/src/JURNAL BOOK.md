# Quick Blog - Antonio RADOSAV 

## learn
- exercise usage of layout
- better understanding of why use layout
- make a scrool down internal link
[what I googled, ](https://www.google.com/search?q=html+scrool+down+link&rlz=1C5CHFA_enGB845GB848&oq=html+scrool+down+link&aqs=chrome..69i57j0l5.7780j0j4&sourceid=chrome&ie=UTF-8)
[page where find the blocker, ](https://www.doodlekit.com/blog/entry/55645/auto-scroll-down-links-internal-anchors)
during the search i find an interesting setting named [SMOOTH SCROOLING, ](https://www.w3schools.com/howto/howto_css_smooth_scroll.asp) code "scroll-behavior: smooth"
-quick css reset
-radial background [what I googled, ](https://www.google.com/search?rlz=1C5CHFA_enGB845GB848&ei=UZznXIjeDLLIxgPO4ImoCA&q=css+radial+background&oq=css+radial+background&gs_l=psy-ab.3..0j0i20i263j0i22i30l8.5052.9436..9666...0.0..0.139.1347.20j1......0....1..gws-wiz.......0i71j35i39j0i67j0i10.or8p3DWi8aA) [and what I find, ](https://www.w3schools.com/cssref/func_radial-gradient.asp) so ellipse is default(can be not writen) or can be set as circle, can use more colors, can use procentage, can chage the position of gradient (default is centre)
-insert a font style (performant version)
-use of free typography
-[css tricls](https://css-tricks.com)
-liniar gradiant background (by inspecting https://css-tricks.com)
- create a theme (change it by code)
- build first for mobile!
- use grid for style
- use classes for css


## modified
- had to add .scrool class to work properly



## ---BLOCKERS---
1. --solved--
scrool down internal link did not worked
 theme - solved by restrarting the console
run the npm start with css (theme problem) - solved by changing the theme
2. --unsolved--

## ---questions---


## ---GitHub Link---
[GitHub Antonio Radosav - quick blog - link](https://github.com/RadosavAntonio/quick-blog)

